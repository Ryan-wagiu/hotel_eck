<?php

date_default_timezone_set('Asia/Jayapura');

$url=$_SERVER['REQUEST_URI'];

?>