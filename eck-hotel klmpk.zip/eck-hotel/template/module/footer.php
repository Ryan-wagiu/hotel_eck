<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0.0 BETA
        </div>
        <strong><a href="#"></a></strong> 
      </footer>