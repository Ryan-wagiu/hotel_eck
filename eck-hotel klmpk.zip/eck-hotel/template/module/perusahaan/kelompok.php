<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Profil kelompok</title>
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
    />
    <link rel="stylesheet" href="index.css" />
  </head>
  <body>
      <div class="container">
        <h1 class="heading">kelompok KOMPUTASI AWAN</h1>
        <div class="card-wrapper">
          <div class="card">
            <img src="https://sbucket020.s3.amazonaws.com/Brightning1.JPG" alt="" class="profil-img" />
            <h1>Christian M.Wowor</h1>
            <a href="#" class="nim"> 19021106010 </a>
            <a href="https://wa.me/6281344848807" class="btn"> Contact me </a>
            <ul class="social-media">
              <li>
                <a href="https://web.facebook.com/kyashi.ronsumbre" target="_blank">
                  <i class="fab fa-facebook-square"> </i>
                </a>
              </li>
              <li>
                <a href="https://telegram.me/Insherne Yr" target="_blank">
                  <i class="fab fa-telegram-plane"></i>
                </a>
              </li>
              <li>
                <a href="https://www.instagram.com/p/CMW568tL-2x/?utm_source=ig_web_copy_link" target="_blank">
                  <i class="fab fa-instagram"> </i>
                </a>
              </li>
            </ul>
          </div>

          <div class="card">
            <img src="https://scontent.fupg2-1.fna.fbcdn.net/v/t1.0-9/82990922_2488384568046556_4573272509536796672_o.jpg?_nc_cat=100&ccb=1-3&_nc_sid=09cbfe&_nc_eui2=AeEunT9PBaVajCzJrviALXJycXSEdOLykbFxdIR04vKRsS223ovOmssIPzkzOzV8xyXsD8VfkiHleB2Ev7y8_T20&_nc_ohc=PoncjMzNDX0AX92xg7B&_nc_ht=scontent.fupg2-1.fna&oh=0bc4c2db90788677dd553fe74d7772fd&oe=6080718E" alt="Elisa" class="profil-img" />
            <h1>Imanuel R.Wagiu</h1>
            <a href="#" class="nim"> 19021106054 </a>
            <a href="https://wa.me/6285394099125" class="btn"> Contact me </a>
            <ul class="social-media">
              <li>
                <a href="https://www.facebook.com/novaldy.pandesia" target="_blank">
                  <i class="fab fa-facebook-square"> </i>
                </a>
              </li>
              <li>
                <a href="https://telegram.me/YourUsername" target="_blank">
                  <i class="fab fa-telegram-plane"></i>
                </a>
              </li>
              <li>
                <a href="https://www.instagram.com/p/B7dzYSxgKTp/?utm_source=ig_web_copy_link" target="_blank">
                  <i class="fab fa-instagram"> </i>
                </a>
              </li>
            </ul>
          </div>

          <div class="card">
            <img src="https://scontent-cgk1-2.xx.fbcdn.net/v/t1.0-9/61284016_2376950185682044_2747042648521965568_o.jpg?_nc_cat=107&ccb=1-3&_nc_sid=8bfeb9&_nc_eui2=AeEH3c8HpDVPn_6O08uQfUC707J5xPMDuN_TsnnE8wO43_6ChqVFB-_dhYLiUZWAg6ZZZmmu8b_n_jhTYe40rlUk&_nc_ohc=a6Q-1dIHfVIAX-yPvTM&_nc_ht=scontent-cgk1-2.xx&oh=f5f8213f4472755b54ad4890af2223d7&oe=607D00F2" alt="" class="profil-img" />
            <h1>Julian M.Maringka</h1>
            <a href="#" class="nim"> 19021106055 </a>
            <a href="https://wa.me/628971675792" class="btn"> Contact me </a>
            <ul class="social-media">
              <li>
                <a href="https://www.facebook.com/daniel.sampe.96/" target="_blank">
                  <i class="fab fa-facebook-square"> </i>
                </a>
              </li>
              <li>
                <a href="https://telegram.me/danieltzz  " target="_blank">
                  <i class="fab fa-telegram-plane" ></i>
                </a>
              </li>
              <li>
                <a href="https://www.instagram.com/danieltz_/" target="_blank">
                  <i class="fab fa-instagram"> </i>
                </a>
              </li>
            </ul>
          </div>

          <div class="card">
            
            <img src="https://scontent-cgk1-2.xx.fbcdn.net/v/t1.0-9/69398672_2372241163013987_8942646059490869248_o.jpg?_nc_cat=101&ccb=1-3&_nc_sid=09cbfe&_nc_eui2=AeE43qgz30FcigvR98a7oGy-BrxmcKW3hDMGvGZwpbeEM-Sl5IcTTLkHnEjsvGhFgaHULMDq0kNgOowCUKpODpdd&_nc_ohc=si1HQBB8CyQAX86oZFN&_nc_oc=AQkWdOakxogCA-0L2l84PfPcn2JjEAt7mULawIQHNkJTRDjdolwspQJXL7in6y693FaYPJZ9bsx0a6cb2fJOhlTI&_nc_ht=scontent-cgk1-2.xx&oh=9f0a7c7e6f78c54dcd1ef2cb2ed93583&oe=608047E3" alt="" class="profil-img" />
            <h1>Novaldy J.Pandesia</h1>
            <a href="#" class="nim"> 19021106083 </a>
            <a href="https://wa.me/6285254657308" class="btn"> Contact me </a>
            <ul class="social-media">
              <li>
                <a href="https://www.facebook.com/julian.maringka" target="_blank">
                  <i class="fab fa-facebook-square"> </i>
                </a>
              </li>
              <li>
                <a href="https://telegram.me/Julianmrchl" target="_blank">
                  <i class="fab fa-telegram-plane"> </i>
                </a>
              </li>
              <li>
                <a href="https://www.instagram.com/p/B7wOrarg-ES3QpD2Rx0fwnHCdgSZkrOn0NOA8I0/"target="_blank">
                  <i class="fab fa-instagram"> </i>
                </a>
              </li>
            </ul>
          </div>

        </div>
      </div>
    <div class="footer">
        
        
       </div>
  </body>
</html>
